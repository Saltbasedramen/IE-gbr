<?php
/**
 * @package 	WordPress
 * @subpackage 	Green Planet Child
 * @version		1.0.0
 * 
 * Child Theme Functions File
 * Created by CMSMasters
 * 
 */


function green_planet_child_enqueue_styles() {
    wp_enqueue_style('green-planet-child-style', get_stylesheet_uri(), array(), '1.0.0', 'screen, print');
}

add_action('wp_enqueue_scripts', 'green_planet_child_enqueue_styles', 11);
?>